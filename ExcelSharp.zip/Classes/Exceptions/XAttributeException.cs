﻿using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml.Linq;

namespace ExcelSharp
{
    [Serializable]
    internal class XAttributeException : Exception
    {
        public XAttributeException()
        {
        }

        public XAttributeException(string? message) : base(message)
        {
        }

        public XAttributeException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected XAttributeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        internal static void ThrowIfEmpty(IEnumerable<XAttribute> attributeCollection, [CallerArgumentExpression(nameof(attributeCollection))] string? paramName = null)
        {
            if (attributeCollection.Count() == 0)
                throw new XAttributeException($"Expected node attributes, but none were found.");
        }
    }
}