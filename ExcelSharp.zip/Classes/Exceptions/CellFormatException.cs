﻿using System.Runtime.Serialization;

namespace ExcelSharp
{
    [Serializable]
    internal class CellFormatException : Exception
    {
        public CellFormatException()
        {
        }

        public CellFormatException(string? message) : base(message)
        {
        }

        public CellFormatException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected CellFormatException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}