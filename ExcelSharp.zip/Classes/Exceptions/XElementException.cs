﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml.Linq;

namespace ExcelSharp
{
    [Serializable]
    internal class XElementException : Exception
    {
        public XElementException()
        {
        }

        public XElementException(string? message) : base(message)
        {
        }

        public XElementException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected XElementException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        internal static void ThrowIfEmpty(IEnumerable<XElement> elementCollection)
        {
            if (elementCollection.Count() == 0)
                throw new XElementException($"Expected node children, but none were found.");
        }

        internal static void ThrowIfNull([NotNull] XElement? element, [CallerArgumentExpression(nameof(element))] string? paramName = null)
        {
            if (element is null)
                throw new XElementException($"Element cannot be null. ({paramName})");
        }
    }
}