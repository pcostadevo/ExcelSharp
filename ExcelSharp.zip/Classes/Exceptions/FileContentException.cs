﻿using System.Runtime.Serialization;

namespace ExcelSharp
{
    /// <summary>
    /// Exception thrown when an exception occurs related to a file's content.
    /// </summary>
    [Serializable]
    internal class FileContentException : Exception
    {
        public FileContentException()
        {
        }

        public FileContentException(string? message) : base(message)
        {
        }

        public FileContentException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected FileContentException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}