﻿using System.Runtime.Serialization;

namespace ExcelSharp.Classes.Exceptions
{
    [Serializable]
    internal class XElementNotFoundException : Exception
    {
        public XElementNotFoundException()
        {
        }

        public XElementNotFoundException(string? message) : base(message)
        {
        }

        public XElementNotFoundException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected XElementNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            
        }        
    }
}