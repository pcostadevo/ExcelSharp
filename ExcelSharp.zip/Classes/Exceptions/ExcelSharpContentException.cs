﻿using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace ExcelSharp
{
    internal class ExcelSharpContentException : Exception
    {
        public ExcelSharpContentException() : base()
        {
        }

        public ExcelSharpContentException(string? message) : base(message)
        {
        }

        public ExcelSharpContentException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        internal static void ThrowIfNotWorksheetNode(XElement baseElement, [CallerArgumentExpression(nameof(baseElement))] string? paramName = null)
        {
            if (baseElement.Name.LocalName != "worksheet")
                throw new ExcelSharpContentException($"Element did not contain expected 'worksheet' child. {paramName}");
        }
    }
}