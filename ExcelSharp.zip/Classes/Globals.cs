﻿global using ExcelSharp.Classes;
global using static ExcelSharp.Classes.Globals;

namespace ExcelSharp.Classes
{
    internal static class Globals
    {
    }
}
