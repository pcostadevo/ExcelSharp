﻿using ExcelSharp.Classes.Exceptions;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace ExcelSharp.Classes.Helpers
{
    public static class XML
    {
        public static bool TryReadAsXML(string s, [NotNullWhen(true)] out XDocument? doc, out Exception? ex)
        {
            ex = null;
            try
            {
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(s)))
                {
                    doc = XDocument.Load(ms);
                }

                return true;
            }
            catch (XmlException xex)
            {
                ex = xex;
                doc = null;
                return false;
            }
        }

        public static IEnumerable<XAttribute> GetAttributes(this XElement element)
        {
            return element.Attributes();
        }
    }
}
