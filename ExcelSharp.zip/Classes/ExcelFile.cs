﻿using ExcelSharp.Classes.Exceptions;
using ExcelSharp.Classes.Helpers;
using System.Xml;
using System.Xml.Linq;

namespace ExcelSharp.Classes
{
    /// <summary>
    /// Represents an Excel file.
    /// </summary>
    public sealed class ExcelFile
    {
        /// <summary>
        /// The Excel file path.
        /// </summary>
        public string FilePath { get; }

        /// <summary>
        /// The temporary folder the contents of the XML are unzipped to.
        /// </summary>
        private DirectoryInfo TempFileFolder { get; }

        /// <summary>
        /// A list of the loaded component files.
        /// </summary>
        private ExcelComponentFiles ComponentFiles { get; set; } = new();
        internal ExcelFile(string filePath, DirectoryInfo tempFileFolder)
        {
            FilePath = filePath;
            TempFileFolder = tempFileFolder;
        }

        internal void LoadContentFromTempFolder()
        {
            var dirInfo = TempFileFolder;

            LoadAllSheets();

            var files = dirInfo.GetFiles();
            var directories = dirInfo.GetDirectories();


        }

        private void LoadAllSheets()
        {
            DirectoryInfo sheetFolder = new DirectoryInfo($@"{TempFileFolder}\xl\worksheets\");

            foreach (FileInfo file in sheetFolder.GetFiles().OrderBy(x => x.Name).ToList())
            {
                if (file.Name.StartsWith("sheet") && file.Name.EndsWith(".xml"))
                {
                    var sheet = new ExcelSheetFile(file.FullName);
                    sheet.Load();
                    ComponentFiles.Sheets.Add(sheet);
                }
            }
        }
    }


    internal enum ComponentFileType
    {
        SharedString,
        Sheet
    }
    internal abstract class ExcelComponentFile
    {
        public ComponentFileType ComponentFileType { get; }
        public bool IsSheet { get => ComponentFileType == ComponentFileType.Sheet; }
        public string AbsoluteFileName { get; }
        protected string? Content { get; set; }
        protected XDocument? Document { get; set; }

        public ExcelComponentFile(ComponentFileType componentFileType, string filePath)
        {
            ComponentFileType = componentFileType;
            AbsoluteFileName = filePath;
        }


        internal virtual void Load()
        {
            Content = File.ReadAllText(AbsoluteFileName);
            bool isXmlContent = XML.TryReadAsXML(Content, out XDocument? doc, out Exception? err);
            if (isXmlContent)
            {
                Document = new(doc!);
            }
            else
            {
                throw new FileContentException("Could not parse the file content to an XDocument.", err);
            }
        }
    }

    internal sealed class ExcelSheetFile : ExcelComponentFile
    {
        internal string UniqueID { get; private set; }

        internal ExcelContent WorksheetContent { get; private set; }

        public ExcelSheetFile(string filePath) : base(ComponentFileType.Sheet, filePath)
        {

        }

        internal override void Load()
        {
            base.Load();

            XElement? worksheetElement = Document!.Element(XName.Get("worksheet"));
            XElementException.ThrowIfNull(worksheetElement);

            WorksheetContent = new ExcelSheetContent(worksheetElement);

            IEnumerable<XAttribute> baseNodeAttributes = WorksheetContent!.Attributes;
            XAttributeException.ThrowIfEmpty(baseNodeAttributes);

            UniqueID = baseNodeAttributes.First(x => x.Name.LocalName == "xr:uid").Value;

            BuildExcelGrid();
        }

        private void BuildExcelGrid()
        {
            XElementException.ThrowIfEmpty(WorksheetContent.ChildElements);
            XElement dimensionNode = GetDimensionElement(children)

            XElement? dimensionNode = children.Where(x => x.Name.LocalName == "dimension").FirstOrDefault();
            XElementException.ThrowIfNull(dimensionNode);



            else
            {
                XElementException.ThrowIfExpectedChildrenDoNotExist(children)
            }
        }

        
    }



    internal sealed class ExcelComponentFiles
    {
        internal List<ExcelSheetFile> Sheets { get; set; } = new();

        internal ExcelComponentFiles()
        {
        }

    }
}
//_files.Sort((x, y) =>
//{
//    int result = x.ComponentFileType.ToString().CompareTo(y.ComponentFileType.ToString());
//    if (result == 0)
//        result = x.AbsoluteFileName.CompareTo(y.AbsoluteFileName);
//    return result;
//});