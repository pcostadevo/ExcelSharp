﻿using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace ExcelSharp.Classes
{
    public interface IExcelContent
    {
        public IEnumerable<XElement> FindChildrenByName(string name);

        public XElement BaseElement { get; }
    }

    internal class ExcelContent : IExcelContent
    {
        private XElement content;
        public ExcelContent(XElement element)
        {
            content = element;
        }
        public XElement BaseElement { get => content; }

        public IEnumerable<XAttribute> Attributes { get => content.Attributes(); }
        public IEnumerable<XElement> ChildElements { get => content.Elements(); }

        public IEnumerable<XElement> FindChildrenByName(string name) => content.Elements().Where(x => x.Name.LocalName == name);
    }

    internal class ExcelSheetContent : ExcelContent
    {
        private XElement worksheetContent;
        internal ExcelSheetContent(XElement baseElement) : base(baseElement)
        {
            ExcelSharpContentException.ThrowIfNotWorksheetNode(baseElement);



        }

        public SheetDimensions Dimensions { get; private set; }

        public struct SheetDimensions
        {
            public SheetCell StartsAt { get; set; }
            public SheetCell EndsAt { get; set; }
            public SheetDimensions(SheetCell start, SheetCell end)
            {
                StartsAt = start;
                EndsAt = end;
            }
            public SheetDimensions(string start, string end)
            {
                StartsAt = SheetCell.Parse(start);
                EndsAt = SheetCell.Parse(end);
            }
        }
        public class SheetCell
        {
            public string Letters { get; }
            public string Numbers { get; }

            private readonly static Regex cellRegex = new Regex("^([A-Z]{1,})([0-9]+$)");
            public SheetCell(string letters, string numbers)
            {
                Letters = letters;
                Numbers = numbers;
            }
            public static SheetCell Parse(string cell)
            {
                Match match = cellRegex.Match(cell);
                (string letters, string numbers) groups = (match.Groups.Values.First().Value, match.Groups.Values.Last().Value);
                if (match.Success)
                {
                    return new SheetCell(groups.letters, groups.numbers);
                }

                throw new CellFormatException("The provided string was not in a valid sheet cell format.");
            }
        }

    }
}
