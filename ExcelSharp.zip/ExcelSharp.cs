﻿using ExcelSharp.Classes;
using System.IO.Compression;

namespace ExcelSharp
{
    public static class ExcelSharp
    {
        public static ExcelFile Load(string filePath)
        {
            return LoadExcelFileFromPath(filePath);
        }

        private static ExcelFile LoadExcelFileFromPath(string filePath)
        {
            byte[] fileAsBytes = File.ReadAllBytes(filePath);

            var tempPath = Directory.CreateTempSubdirectory("excelsharp_");

            ZipFile.ExtractToDirectory(filePath, tempPath.FullName);

            ExcelFile excelFile = new ExcelFile(filePath, tempPath);

            excelFile.LoadContentFromTempFolder();

            return excelFile;
        }




    }
}

